import { useState, useEffect, useRef } from "react";
import { ref, onValue, set, update } from "firebase/database";
import { db } from "../services/firebase";
import Header from "../components/Header";
import Calibration from "./Calibration";
import { motion, AnimatePresence } from "framer-motion";
import { useNavigate } from "react-router-dom";

// Circular Progress Bar Component
const CircularProgress = ({ progress }) => {
    const radius = 50;
    const circumference = 2 * Math.PI * radius;
    const offset = circumference - (progress / 100) * circumference;

    return (
        <svg className="w-40 h-40" viewBox="0 0 120 120">
            <circle cx="60" cy="60" r={radius} className="stroke-gray-200" strokeWidth="10" fill="transparent" />
            <motion.circle
                cx="60" cy="60" r={radius} className="stroke-blue-600"
                strokeWidth="10" fill="transparent"
                strokeDasharray={circumference}
                strokeDashoffset={offset}
                strokeLinecap="round"
                transform="rotate(-90 60 60)"
                initial={{ strokeDashoffset: circumference }}
                animate={{ strokeDashoffset: offset }}
                transition={{ duration: 1, ease: "linear" }}
            />
        </svg>
    );
};


export default function Sessions() {
    const navigate = useNavigate();
    const username = localStorage.getItem("loggedInUser") || "Unknown User";

    const [hasCalibration, setHasCalibration] = useState(false);
    const [isLoading, setIsLoading] = useState(true);
    const [showTimerModal, setShowTimerModal] = useState(false);
    const [selectedTime, setSelectedTime] = useState(30);
    const [sessionStatus, setSessionStatus] = useState("idle");
    const [sessionTime, setSessionTime] = useState(0);
    const [history, setHistory] = useState([]);
    const [sensorStatus, setSensorStatus] = useState(null); // Initialized to null for loading check
    
    const sessionTimerRef = useRef(null);

    // Check for calibration
    useEffect(() => {
        if (!username) return;
        const calibrationRef = ref(db, `calibration/${username}`);
        const unsubscribe = onValue(calibrationRef, (snapshot) => {
            setHasCalibration(!!snapshot.val());
            setIsLoading(false); // Stop loading after calibration check
        });
        return () => unsubscribe();
    }, [username]);

    // Check the main sensor power status from the 'sensor' table
    useEffect(() => {
        if (!username) return;
        const sensorStateRef = ref(db, `sensor/${username}`);
        const unsubscribe = onValue(sensorStateRef, (snapshot) => {
            const data = snapshot.val();
            setSensorStatus(data?.status || 'off');
        });
        return () => unsubscribe();
    }, [username]);

    // This useEffect handles the redirect logic if the sensor is off
    useEffect(() => {
        // Don't do anything until the status has been loaded from Firebase
        if (sensorStatus === null) {
            return;
        }

        if (sensorStatus === 'off') {
            alert("Your sensor is disconnected. Please turn it on from the Home page first.");
            navigate('/home');
        }
    }, [sensorStatus, navigate]);


    // Load session history
    useEffect(() => {
        if (!username) return;
        const historyRef = ref(db, `history/${username}`);
        const unsubscribe = onValue(historyRef, (snapshot) => {
            const data = snapshot.val() || {};
            const historyList = Object.keys(data)
                .map(key => ({ id: key, ...data[key] }))
                .sort((a, b) => new Date(b.sessionEndTime) - new Date(a.sessionEndTime));
            setHistory(historyList);
        });
        return () => unsubscribe();
    }, [username]);

    // Load and manage the live session state from 'sensorStatus' table
    useEffect(() => {
        if (!username) return;
        const sessionRef = ref(db, `sensorStatus/${username}`);
        const unsubscribe = onValue(sessionRef, (snapshot) => {
            const data = snapshot.val();
            if (data && data.status === "active") {
                setSessionStatus("active");
                setSelectedTime(data.duration);
                setSessionTime(data.sessionTime || 0);

                if (!sessionTimerRef.current) {
                    startTimer(data.duration, data.sessionTime || 0);
                }
            } else {
                setSessionStatus("idle");
                if (sessionTimerRef.current) clearInterval(sessionTimerRef.current);
                sessionTimerRef.current = null;
            }
        });
        return () => {
            unsubscribe();
            if (sessionTimerRef.current) clearInterval(sessionTimerRef.current);
        };
    }, [username]);

    const startTimer = (durationMinutes, startFromSeconds = 0) => {
        if (sessionTimerRef.current) clearInterval(sessionTimerRef.current);

        sessionTimerRef.current = setInterval(() => {
            setSessionTime(prev => {
                const newTime = prev + 1;
                if (newTime >= durationMinutes * 60) {
                    endSession(newTime);
                    return durationMinutes * 60;
                }
                return newTime;
            });
        }, 1000);

        setSessionTime(startFromSeconds);
    };

    const confirmStartSession = () => {
        setShowTimerModal(false);
        setSessionStatus("active");
        setSessionTime(0);

        const sessionData = {
            status: "active",
            username,
            duration: selectedTime,
            sessionTime: 0,
            startTime: new Date().toISOString()
        };
        set(ref(db, `sensorStatus/${username}`), sessionData);
    };

    const endSession = (finalTime = sessionTime) => {
        if (sessionTimerRef.current) clearInterval(sessionTimerRef.current);
        sessionTimerRef.current = null;
        
        setSessionStatus("completed");
        setTimeout(() => setSessionStatus("idle"), 1500);

        update(ref(db, `sensorStatus/${username}`), {
            status: "completed",
            sessionTime: finalTime,
            endTime: new Date().toISOString()
        });
    };

    const formatTime = (seconds) => {
        const mins = Math.floor(seconds / 60).toString().padStart(2, '0');
        const secs = (seconds % 60).toString().padStart(2, '0');
        return `${mins}:${secs}`;
    };

    const calculateScore = (session) => {
        const total = (session.goodCount || 0) + (session.moderateCount || 0) + (session.badCount || 0);
        return total > 0 ? Math.round(((session.goodCount || 0) / total) * 100) : 0;
    };

    // Show loading screen until both calibration and sensor status are checked
    if (isLoading || sensorStatus === null) {
        return <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center"><p>Loading...</p></div>;
    }
    if (!hasCalibration) {
        return <Calibration />;
    }

    return (
        <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 px-4 py-6">
            <Header />
            <div className="max-w-4xl mx-auto mt-6">
                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
                    <h1 className="text-3xl font-bold text-gray-800 mb-2">Monitoring Sessions</h1>
                    <p className="text-gray-600 mb-6">Manage and track your posture monitoring sessions.</p>
                </motion.div>
                
                <motion.div 
                    layout
                    className="bg-white rounded-2xl p-6 shadow-md mb-8 flex flex-col items-center text-center"
                    initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{delay: 0.1}}
                >
                    <AnimatePresence mode="wait">
                        {sessionStatus !== "active" ? (
                            <motion.div
                                key="start"
                                initial={{ opacity: 0, scale: 0.9 }}
                                animate={{ opacity: 1, scale: 1 }}
                                exit={{ opacity: 0, scale: 0.9 }}
                            >
                                <h2 className="text-xl font-bold text-gray-800 mb-4">Ready to improve your posture?</h2>
                                <motion.button
                                    onClick={() => setShowTimerModal(true)}
                                    className="bg-blue-600 text-white font-semibold py-3 px-8 rounded-lg shadow-lg hover:bg-blue-700 transition"
                                    whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}
                                >
                                    Start New Session
                                </motion.button>
                            </motion.div>
                        ) : (
                            <motion.div
                                key="active"
                                className="w-full flex flex-col items-center"
                                initial={{ opacity: 0, scale: 0.9 }}
                                animate={{ opacity: 1, scale: 1 }}
                                exit={{ opacity: 0, scale: 0.9 }}
                            >
                                <div className="relative mb-4">
                                    <CircularProgress progress={(sessionTime / (selectedTime * 60)) * 100} />
                                    <div className="absolute inset-0 flex flex-col items-center justify-center">
                                        <p className="text-4xl font-bold text-blue-600">{formatTime(sessionTime)}</p>
                                        <p className="text-sm text-gray-500">of {selectedTime} min</p>
                                    </div>
                                </div>
                                <div className="text-green-600 font-medium mb-4 flex items-center">
                                    <span className="relative flex h-3 w-3 mr-2">
                                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                                        <span className="relative inline-flex rounded-full h-3 w-3 bg-green-500"></span>
                                    </span>
                                    Session Active
                                </div>
                                <motion.button
                                    onClick={() => endSession()}
                                    className="bg-red-500 text-white font-semibold py-2 px-6 rounded-lg shadow hover:bg-red-600 transition"
                                    whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}
                                >
                                    End Session
                                </motion.button>
                            </motion.div>
                        )}
                    </AnimatePresence>
                </motion.div>
                
                <motion.div 
                    className="bg-white rounded-2xl p-6 shadow-md"
                    initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{delay: 0.2}}
                >
                    <h2 className="text-xl font-bold text-gray-800 mb-4">Session History</h2>
                    <div className="space-y-3 max-h-[300px] overflow-y-auto pr-2">
                        {history.length > 0 ? history.map(session => (
                            <div key={session.id} className="p-4 border rounded-lg flex justify-between items-center">
                                <div>
                                    <p className="font-semibold text-gray-700">{new Date(session.sessionEndTime).toLocaleDateString()}</p>
                                    <p className="text-sm text-gray-500">{formatTime(session.durationSeconds || 0)}</p>
                                </div>
                                <div>
                                    <p className="text-sm text-gray-500">Score</p>
                                    <p className="font-bold text-lg text-blue-600">{calculateScore(session)}%</p>
                                </div>
                            </div>
                        )) : <p className="text-center text-gray-500 py-4">No completed sessions yet.</p>}
                    </div>
                </motion.div>
            </div>

            <AnimatePresence>
                {showTimerModal && (
                    <motion.div 
                        className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50"
                        initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}}
                    >
                        <motion.div 
                            className="bg-white rounded-2xl p-6 w-full max-w-sm"
                            initial={{y: 50, opacity:0}} animate={{y:0, opacity:1}} exit={{y:50, opacity:0}}
                        >
                            <h3 className="text-xl font-bold text-gray-800 mb-4">Select Session Duration</h3>
                            <div className="grid grid-cols-3 gap-3 mb-6">
                                {[10, 20, 30, 45, 60, 90].map((time) => (
                                    <button
                                        key={time} onClick={() => setSelectedTime(time)}
                                        className={`py-3 rounded-lg border-2 font-semibold transition ${
                                            selectedTime === time ? "border-blue-600 bg-blue-50 text-blue-700" : "border-gray-200 text-gray-700 hover:border-blue-300"
                                        }`}
                                    >{time} min</button>
                                ))}
                            </div>
                            <div className="flex space-x-3">
                                <button onClick={() => setShowTimerModal(false)} className="flex-1 bg-gray-200 text-gray-700 py-3 rounded-lg font-semibold hover:bg-gray-300 transition">Cancel</button>
                                <button onClick={confirmStartSession} className="flex-1 bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition">Start Session</button>
                            </div>
                        </motion.div>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
}